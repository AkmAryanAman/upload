from django.shortcuts import render, redirect
from SewakarApp.models.feedback import Query, Comment_Query
from django.views import View


class HelpCenter(View):
    def get(self, request):
        data = {'Query': Query.objects.all().order_by('-id')}
        return render(request,"help_center.html", data)

    def post(self, request):
        pass
