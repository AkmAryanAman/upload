from django.shortcuts import render, redirect
from django.views import View
from SewakarApp.models.Service import ServiceDomain, ServiceSubDomain
from SewakarApp.models.booking_model import BookingModel, PaymentDetails, Scheduling
from SewakarApp.models.signup import SignUp
from SewakarApp.models.location import State, District
from SewakarApp.models import WorkStatus
from SewakarApp.models.booking_address import Booking_Address
from datetime import date
from json import dumps


class Schedule_List_For_Worker(View):
    def get(self, request):
        User = request.session.get('id')
        if User:
            data = {'user': SignUp.objects.get(id=User)}
            data['Schedule'] = Scheduling.objects.filter(Worker=data['user']).order_by('-Booking')

            return render(request, 'Schedule_for_Worker.html', data)

        return redirect('login')

    def post(self, request):
        pass