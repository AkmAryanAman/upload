from django.shortcuts import render, redirect
from SewakarApp.models.Service import ServiceSubDomain
from django.views import View


class AllServices(View):
    def get(self, request):
        data = {'Service': ServiceSubDomain.objects.all()}
        return render(request, "service.html", data)

    def post(self, request):
        pass


def Policy(request):
    return render(request, "policy.html")
