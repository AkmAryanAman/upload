from django.shortcuts import render, redirect
from django.contrib.auth.hashers import make_password
from SewakarApp.models.signup import Category
from SewakarApp.models import SignUp
from django.views import View
from SewakarApp.models.booking_model import Booking_Address, BookingModel, Scheduling


class Booking_List(View):
    def get(self, request):
        Cat_id = request.session.get('category')
        if Cat_id == 3:
            data = {'Booking_List': BookingModel.objects.all(),
                    'Schedule': Scheduling.objects.all()}
            return render(request, 'Booking_list.html', data)
        else:
            return redirect('main')

    def post(self, request):
        return redirect('Booking_List')