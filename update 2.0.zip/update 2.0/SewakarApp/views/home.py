from django.shortcuts import render, redirect
from django.views import View


class Index(View):

    def post(self, request):
        return redirect('home')

    def get(self, request):
        return render(request, "index.html")
