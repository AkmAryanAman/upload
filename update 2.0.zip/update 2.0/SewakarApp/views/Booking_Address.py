from django.shortcuts import render, redirect
from django.views import View
from SewakarApp.models.Service import ServiceDomain, ServiceSubDomain, ServiceWorker
from SewakarApp.models import SignUp
from SewakarApp.models.location import State, District
from SewakarApp.models import WorkStatus
from SewakarApp.models.booking_address import Booking_Address
from SewakarApp.models.booking_model import BookingModel
from datetime import date


class BookingAddress(View):

    def get(self, request):
        data = {}
        User = request.session.get('id')
        try:
            cart = None
            if request.session.get('cart'):
                cart = request.session['cart']
        finally:
            pass

        if User:
            if cart:
                data['user'] = SignUp.objects.get(id=User)
                data['pre_address'] = Booking_Address.Get_Address_by_user(data['user'])
                data['State'] = State.objects.all()

                address = request.GET.get('Address')
                if address:
                    Address = Booking_Address.objects.get(id=address)
                else:
                    state = request.GET.get('State')
                    if state:
                        data['state'] = State.objects.get(id=state)
                        data['District'] = District.Get_District_By_State(data['state'])

                        return render(request, 'booking_address.html', data)

                    else:
                        return render(request, 'booking_address.html', data)

                return render(request, 'booking_address.html', data)
            else:
                return redirect('Booking_Form')
        else:
            return redirect('login')

    def post(self, request):

        user = request.POST.get('user_id')
        state = request.POST.get('Select_State')
        district = request.POST.get('Select_District')
        address = request.POST.get('Address')
        pincode = request.POST.get('PinCode')

        if user:
            User = SignUp.objects.get(id=user)
            if address and district:
                district = District.objects.get(id=district)
                booking_address = Booking_Address(User=User,
                                                  Address=address,
                                                  District=district,
                                                  PinCode=pincode)

                booking_address.register()

                address_1 = Booking_Address.Get_Address_by_user(User)

                cart = request.session['cart']


                Quantity = cart['Quantity']
                Duration = cart['Duration']
                Date = cart['Date']
                Worker = ServiceWorker.objects.get(id=cart['Worker'])
                work_status = WorkStatus.objects.get(id=1)

                bookingModel = BookingModel(User=User,
                                            Quantity=Quantity,
                                            Duration=Duration,
                                            Location=address_1.last(),
                                            Date=Date,
                                            Service=Worker,
                                            Status=work_status,
                                            Amount=0)

                bookingModel.register()


                # Delete Cart from session
                try:
                    del request.session['cart']
                finally:
                    pass

                return redirect('booking')
            else:
                error = "Enter Valid Address.."
                return render(request, 'booking_address.html', {'error': error})
        else:
            return redirect('login')


def BookingOnPreviousAddress(request):
    user = request.session.get('id')
    User = SignUp.objects.get(id=user)

    address = request.POST.get('Address_Id')
    Address = Booking_Address.objects.get(id=address)

    cart = request.session['cart']

    Quantity = cart['Quantity']
    Duration = cart['Duration']
    Date = cart['Date']
    Worker = ServiceWorker.objects.get(id=cart['Worker'])
    work_status = WorkStatus.objects.get(id=1)

    bookingModel = BookingModel(User=User,
                                Quantity=Quantity,
                                Duration=Duration,
                                Location=Address,
                                Date=Date,
                                Service=Worker,
                                Status=work_status,
                                Amount=0)

    bookingModel.register()

    # Delete Cart from session
    try:
        del request.session['cart']
    finally:
        pass

    return redirect('booking')


def DeletePreviousAddress(request):
    address = request.POST.get('Address_Id')
    Booking_Address.objects.get(id=address).delete()

    return redirect('Booking_Address')
