from django.urls import path
from SewakarApp.views import help_center,  about_us, contact_us
from SewakarApp.views import login, home, worker, Profile, signup, services
from SewakarApp.views import Booking_Cart, Booking_Address, Booking_Form
from SewakarApp.views import SearchWorker, Booking_list, schedule_list
from SewakarApp.views import schedule_for_worker

urlpatterns = [
    path('', home.Index.as_view(), name='main'),
    path('signup', signup.Signup.as_view(), name='signup'),
    path('login', login.Login.as_view(), name='login'),
    path('service',services.AllServices.as_view(), name='service'),


    path('profile', Profile.Profile.as_view(), name='profile'),
    path('profile/Update_Password', Profile.Update_Password, name='Update_Password'),
    path('profile/Update_Basic_Details', Profile.Update_Basic_Details, name='Update_Basic_Details'),
    path('profile/Update_Work', Profile.UpdateWork, name='Update_Work'),
    path('profile/Remove_Work', Profile.RemoveWork, name='Remove_Work'),
    path('profile/Update_Address', Profile.Update_Address, name='Update_Address'),


    path('booking', Booking_Cart.Booking.as_view(), name='booking'),
    path('booking/Booking_Form', Booking_Form.BookingForm.as_view(), name='Booking_Form'),
    path('booking/Booking_Address', Booking_Address.BookingAddress.as_view(), name='Booking_Address'),
    path('booking/Booking_Address/Previous_Address', Booking_Address.BookingOnPreviousAddress, name='Booking_On_Address'),
    path('booking/Booking_Address/Delete_Address', Booking_Address.DeletePreviousAddress, name='Remove_Address'),
    path('worker', worker.Worker.as_view(), name='worker'),
    path('worker/Verify_Worker', worker.Verify_Worker, name='Verify_Worker'),

    path('Booking_List', Booking_list.Booking_List.as_view(), name='Booking_List'),
    path('Booking_List/Search_Worker', SearchWorker.Search_Worker.as_view(), name='Search_Worker'),
    path('Booking_List/Search_Worker/Update_Amount', SearchWorker.UpdateAmount, name='Update_Amount'),
    path('Booking_List/Search_Worker/Add_Payment', SearchWorker.Add_Payment, name='Add_Payment'),
    path('Booking_List/Search_Worker/Schedule', SearchWorker.Schedule, name='Schedule'),
    path('Booking_List/Search_Worker/Accept_Booking', SearchWorker.AcceptBooking, name='Accept_Booking'),
    path('Booking_List/Search_Worker/Delete_Booking', SearchWorker.DeleteBooking, name='Delete_Booking'),
    path('Booking_List/Search_Worker/Schedule/Remove_Schedule', SearchWorker.Remove_Schedule_Worker,
         name='Remove_Schedule'),

    path('Schedule_List', schedule_list.Schedule_List.as_view(), name='Schedule_List'),
    path('Schedule_List_For_Worker', schedule_for_worker.Schedule_List_For_Worker.as_view(),
         name='Schedule_List_For_Worker'),

    path('remove', Booking_Cart.RemoveBooking, name='remove'),
    path('help_center', help_center.HelpCenter.as_view(), name='help_center'),
    path('contact_us', contact_us.ContactUs.as_view(), name='contact_us'),
    path('about_us', about_us.AboutUs.as_view(), name='about_us'),


    path('logout', login.logout, name='logout'),
]
