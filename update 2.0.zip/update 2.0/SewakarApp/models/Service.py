from django.db import models


# This Model Identify , What Domain we have and the SubDomain of that Domain
# This Domain is the industrial Name and SubDomain is the Position inside Industries
class ServiceDomain(models.Model):
    Domain = models.CharField(max_length=50, default='')

    def register(self):
        self.save()

    def __str__(self):
        return self.Domain

    # returns all the services if It have
    @staticmethod
    def get_all_services():
        return ServiceDomain.objects.all()


# This module have collections of subdomain using Domain
class ServiceSubDomain(models.Model):
    Domain = models.ForeignKey(ServiceDomain, on_delete=models.CASCADE, default='')
    SubDomain = models.CharField(max_length=40, default='')
    image = models.ImageField(upload_to='upload/products', default='')

    def register(self):
        self.save()

    def __str__(self):
        return self.SubDomain

    # returns all the SubDomain by Domain
    @staticmethod
    def get_all_SubDomain_By_Domain(Domain):
        try:
            result = False
            if ServiceSubDomain.objects.filter(Domain=Domain):
                result = ServiceSubDomain.objects.filter(Domain=Domain)
            else:
                pass
        finally:
            return result

    # returns all Domains with Subdomain
    @staticmethod
    def get_all_Domain():
        return ServiceSubDomain.objects.all()


# This module have collections of subdomain using Domain
class ServiceWorker(models.Model):
    SubDomain = models.ForeignKey(ServiceSubDomain, on_delete=models.CASCADE, default='')
    Worker = models.CharField(max_length=50, default='')

    def register(self):
        self.save()

    def __str__(self):
        return self.Worker

    # returns all the worker by SubDomain
    @staticmethod
    def get_all_Worker_By_SubDomain(SubDomain):
        try:
            result = False
            if ServiceWorker.objects.filter(SubDomain=SubDomain):
                result = ServiceWorker.objects.filter(SubDomain=SubDomain)
            else:
                result = False
        finally:
            return result
