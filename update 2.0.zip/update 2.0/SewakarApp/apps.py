from django.apps import AppConfig


class SewakarAppConfig(AppConfig):
    name = 'SewakarApp'
