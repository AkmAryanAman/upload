from django.db import models


class ServiceModel(models.Model):
    Type = models.CharField(max_length=50, default='')

    def register(self):
        self.save()

    def __str__(self):
        return self.Type

    @staticmethod
    def get_all_services():
        return ServiceModel.objects.all


class Position(models.Model):
    Profession = models.ForeignKey(ServiceModel, on_delete=models.CASCADE, default='')
    Name = models.CharField(max_length=40, default='')

    def register(self):
        self.save()

    def __str__(self):
        return self.Name