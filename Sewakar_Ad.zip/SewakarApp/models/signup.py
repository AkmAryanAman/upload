from django.db import models
from .Category import Category


class SignUp(models.Model):
    First_name = models.CharField(max_length=30, default='')
    Last_name = models.CharField(max_length=30, default='')
    Mobile = models.CharField(max_length=13)
    Email = models.CharField(max_length=50, default='')
    Password = models.CharField(max_length=200, default='')
    Category = models.ForeignKey(Category, on_delete=models.CASCADE, default='')

    def register(self):
        self.save()

    def __str__(self):
        return self.Email

    def isExists(self):
        if SignUp.objects.filter(Email=self.Email):
            return True

        return False

    @staticmethod
    def get_people_by_email(email):
        try:
            return SignUp.objects.get(Email=email)
        except:
            return False
