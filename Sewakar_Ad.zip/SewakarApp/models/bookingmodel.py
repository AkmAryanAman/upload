from django.db import models
from .Service import ServiceModel
from .Status import Status
from .signup import SignUp


class BookingModel(models.Model):
    User = models.ForeignKey(SignUp, on_delete=models.CASCADE, default='')
    Quantity = models.IntegerField()
    Duration = models.IntegerField()
    Location = models.CharField(max_length=200, default='')
    Date = models.DateField()
    Service = models.ForeignKey(ServiceModel, on_delete=models.CASCADE, default='')
    Status = models.ForeignKey(Status, on_delete=models.CASCADE, default='')
    Amount = models.IntegerField()

    def register(self):
        self.save()



