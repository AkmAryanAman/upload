from django.contrib import admin
from SewakarApp.models import Category
from SewakarApp.models import SignUp
from SewakarApp.models import Status
from SewakarApp.models import ServiceModel
from SewakarApp.models.bookingmodel import BookingModel


class AdminCategory(admin.ModelAdmin):
    list_display = ['Type']


class AdminStatus(admin.ModelAdmin):
    list_display = ['Type']


class AdminService(admin.ModelAdmin):
    list_display = ['Type']


class AdminSignUp(admin.ModelAdmin):
    list_display = ['First_name', 'Last_name', 'Email', 'Mobile', 'Category', 'Password']


class AdminBooking(admin.ModelAdmin):
    list_display = ['User', 'Quantity', 'Duration', 'Location', 'Date', 'Service', 'Status', 'Amount']


# Register your models here.
admin.site.register(Category, AdminCategory)
admin.site.register(Status, AdminStatus)
admin.site.register(ServiceModel, AdminService)
admin.site.register(SignUp, AdminSignUp)
admin.site.register(BookingModel, AdminBooking)
