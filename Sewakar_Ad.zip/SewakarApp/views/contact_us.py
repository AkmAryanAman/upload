from django.shortcuts import render, redirect
from django.views import View


class ContactUs(View):
    def get(self, request):
        return render(request,"contact_us.html")

    def post(self, request):
        pass
