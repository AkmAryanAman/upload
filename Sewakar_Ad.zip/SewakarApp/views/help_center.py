from django.shortcuts import render, redirect
from django.views import View


class HelpCenter(View):
    def get(self, request):
        return render(request,"help_center.html")

    def post(self, request):
        pass
