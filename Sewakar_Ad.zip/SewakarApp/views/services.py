from django.shortcuts import render, redirect
from django.views import View


class AllServices(View):
    def get(self, request):
        return render(request, "service.html")

    def post(self, request):
        pass


def Policy(request):
    return render(request, "policy.html")
