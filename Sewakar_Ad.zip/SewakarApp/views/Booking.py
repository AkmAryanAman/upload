from django.shortcuts import render, redirect
from django.views import View
from SewakarApp.models import ServiceModel
from SewakarApp.models.bookingmodel import BookingModel
from SewakarApp.models import SignUp
from SewakarApp.models import Status
from datetime import date


class Booking(View):
    def get(self, request):

        services = ServiceModel.get_all_services()
        User = request.session.get('id')

        if User:

            User_id = SignUp.objects.get(id=User)
            booking = False
            try:
                booking = BookingModel.objects.filter(User=User_id)
            finally:
                pass
            if booking:
                return render(request, "Booking.html", {'services': services, 'booking': booking})

        return render(request, "Booking.html", {'services': services})

    def post(self, request):
        User = request.session.get('id')
        Quantity = request.POST.get('Quantity')
        Duration = request.POST.get('Duration')
        Location = request.POST.get('Location')
        Date = request.POST.get('Date')
        service = request.POST.get('Service')

        error_msg = ""

        if service == '0':
            error_msg = "Please Select Service.."
        else:
            if Date <= str(date.today()):
                error_msg = "Please Enter valid date.."

        if error_msg != "":
            services_all = ServiceModel.get_all_services()
            value = {'Quantity': Quantity,
                     'Duration': Duration,
                     'Location': Location,
                     'Date': Date,
                     'Service': service}

            data = {'services': services_all,
                    'value': value,
                    'error': error_msg}

            return render(request, "Booking.html", data)

        else:
            User = SignUp.objects.get(id=User)
            status = Status.objects.get(id=1)
            service = ServiceModel.objects.get(id=service)
            Amount = "0"

            booking = BookingModel(User=User,
                                   Quantity=Quantity,
                                   Duration=Duration,
                                   Location=Location,
                                   Date=Date,
                                   Service=service,
                                   Status=status,
                                   Amount=Amount)

            booking.register()
            confirm_msg = "Your Booking has been done..."

            User = request.session.get('id')

            if User:

                User_id = SignUp.objects.get(id=User)
                booking = False
                try:
                    booking = BookingModel.objects.filter(User=User_id)
                finally:
                    pass
                if booking:
                    return render(request, "Booking.html", {'confirm_msg': confirm_msg, 'booking': booking})
            return render(request, "Booking.html", {'confirm_msg': confirm_msg})


def RemoveBooking(request):
    booking_id = request.POST.get('remove_tag')
    BookingModel.objects.get(id=booking_id).delete()
    return redirect('booking')
