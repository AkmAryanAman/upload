from django.urls import path
from SewakarApp.views import help_center, Profile, signup
from SewakarApp.views import login, Booking, home, contact_us

urlpatterns = [
    path('', home.Index.as_view(), name='main'),
    path('signup', signup.Signup.as_view(), name='signup'),
    path('login', login.Login.as_view(), name='login'),
    path('profile', Profile.Profile.as_view(), name='profile'),
    path('booking', Booking.Booking.as_view(), name='booking'),
    path('remove', Booking.RemoveBooking, name='remove'),
    path('help_center', help_center.HelpCenter.as_view(), name='help_center'),
    path('contact_us', contact_us.ContactUs.as_view(), name='contact_us'),
    path('logout', login.logout, name='logout'),
]
