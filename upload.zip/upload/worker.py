from django.shortcuts import render, redirect
from django.contrib.auth.hashers import make_password
from SewakarApp.models import SignUp
from django.views import View
from SewakarApp.models import Category


class Worker(View):
    def get(self, request):
        Cat_id = request.session.get('category')
        if Cat_id == 3:
            category = Category.objects.get(id=2)
            worker = SignUp.objects.filter(Category=category)
            return render(request, 'Worker.html', {'worker': worker})
        else:
            return redirect('main')

    def post(self, request):
        return redirect('worker')
