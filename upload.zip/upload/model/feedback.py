from django.db import models
import datetime


class Feedback(models.Model):
    Name = models.CharField(max_length=50, default='')
    Email = models.CharField(max_length=50, default='')
    Feedback = models.CharField(max_length=500, default='')

    def register(self):
        self.save()


class Query(models.Model):
    Name = models.CharField(max_length=50, default='')
    Email = models.CharField(max_length=50, default='')
    Subject = models.CharField(max_length=100, default='')
    Query = models.CharField(max_length=500, default='')
    Type = models.IntegerField(default=0)

    def register(self):
        self.save()


class Comment_Query(models.Model):
    Query = models.ForeignKey(Query, on_delete=models.CASCADE)
    Comment = models.CharField(max_length=500, default='')
    Date = models.DateField(datetime.date.today())

    def register(self):
        self.save()


class Work_With_us(models.Model):
    Name = models.CharField(max_length=100)
    DOB = models.DateField()
    Mobile = models.IntegerField(default=0)
    Email = models.CharField(max_length=100)
    Adhar = models.IntegerField(default=0)
    Address = models.CharField(max_length=200)
    State = models.CharField(max_length=50)
    PinCode = models.IntegerField(default=0)
    Qualification = models.CharField(max_length=50)
    Skills = models.CharField(max_length=100)
    Work = models.CharField(max_length=30)
    Work_State = models.CharField(max_length=100)
    Work_Location = models.CharField(max_length=100)
    Experience = models.CharField(max_length=100)
    Rate = models.IntegerField(default=0)
    Adhar_image = models.ImageField(upload_to='upload/Adhar', default='')
    Image = models.ImageField(upload_to='upload/Image', default='')

    def register(self):
        self.save()
