from django.db import models
from .Service import ServiceContractor
from .work_Status import WorkStatus
from .signup import SignUp
from .booking_address import Booking_Address


# This Model Collect the Booking Information
class Booking_Contractor(models.Model):
    User = models.ForeignKey(SignUp, on_delete=models.CASCADE, default='')
    Quantity = models.IntegerField()
    Duration = models.IntegerField()

    # Full location Find on Booking Address
    Location = models.ForeignKey(Booking_Address, on_delete=models.CASCADE, default='')
    Date = models.DateField()

    # this Service is Worker - More Details in Service
    Service = models.ForeignKey(ServiceContractor, on_delete=models.CASCADE, default='')

    # This is Working Status
    Status = models.ForeignKey(WorkStatus, on_delete=models.CASCADE, default='')
    Amount = models.IntegerField()

    def register(self):
        self.save()

    # function return Booking By users
    @staticmethod
    def Get_Booking_By_User(User):
        try:
            result = False
            if Booking_Contractor.objects.filter(User=User):
                result = Booking_Contractor.objects.filter(User=User).order_by("-Date")
        finally:
            return result

    # function return Booking By Date
    @staticmethod
    def Get_Booking_By_Date(Date):
        try:
            result = False
            if Booking_Contractor.objects.filter(Date=Date):
                result = Booking_Contractor.objects.filter(Date=Date)
        finally:
            return result


# Payment Details
class Contractor_Payment(models.Model):
    User = models.ForeignKey(SignUp, on_delete=models.CASCADE)
    Booking = models.ForeignKey(Booking_Contractor, on_delete=models.CASCADE)
    Reference_No = models.CharField(max_length=100, default='')
    Amount = models.IntegerField()

    def register(self):
        self.save()

    @staticmethod
    def Get_Payment_By_Booking(Booking):
        try:
            result = False
            if Contractor_Payment.objects.get(Booking=Booking):
                result = Contractor_Payment.objects.get(Booking_id=Booking)
        finally:
            return result



