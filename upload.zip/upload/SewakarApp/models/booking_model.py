from django.db import models
from .Service import ServiceWorker
from .work_Status import WorkStatus
from .signup import SignUp
from .booking_address import Booking_Address


# This Model Collect the Booking Information
class BookingModel(models.Model):
    User = models.ForeignKey(SignUp, on_delete=models.CASCADE, default='')
    Quantity = models.IntegerField()
    Duration = models.IntegerField()

    # Full location Find on Booking Address
    Location = models.ForeignKey(Booking_Address, on_delete=models.CASCADE, default='')
    Date = models.DateField()

    # this Service is Worker - More Details in Service
    Service = models.ForeignKey(ServiceWorker, on_delete=models.CASCADE, default='')

    # This is Working Status
    Status = models.ForeignKey(WorkStatus, on_delete=models.CASCADE, default='')
    Amount = models.IntegerField()

    def register(self):
        self.save()

    # function return Booking By users
    @staticmethod
    def Get_Booking_By_User(User):
        try:
            result = False
            if BookingModel.objects.filter(User=User):
                result = BookingModel.objects.filter(User=User).order_by("-Date")
        finally:
            return result

    # function return Booking By Date
    @staticmethod
    def Get_Booking_By_Date(Date):
        try:
            result = False
            if BookingModel.objects.filter(Date=Date):
                result = BookingModel.objects.filter(Date=Date)
        finally:
            return result


# Payment Details
class PaymentDetails(models.Model):
    User = models.ForeignKey(SignUp, on_delete=models.CASCADE)
    Booking = models.ForeignKey(BookingModel, on_delete=models.CASCADE)
    Reference_No = models.CharField(max_length=100, default='')
    Amount = models.IntegerField()

    def register(self):
        self.save()

    @staticmethod
    def Get_Payment_By_Booking(Booking):
        try:
            result = False
            if PaymentDetails.objects.get(Booking=Booking):
                result = PaymentDetails.objects.get(Booking_id=Booking)
        finally:
            return result


# This Model is using for Scheduling
class Scheduling(models.Model):
    Booking = models.ForeignKey(BookingModel, on_delete=models.CASCADE)
    Worker = models.ForeignKey(SignUp, on_delete=models.CASCADE)

    def register(self):
        self.save()


