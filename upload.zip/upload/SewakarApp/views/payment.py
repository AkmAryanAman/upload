from django.shortcuts import render, redirect
from SewakarApp.models.booking_model import BookingModel, PaymentDetails

from django.views import View


class Payment_Receipt(View):
    def get(self,request):
        id = request.GET.get('Booking_id')
        data = {'Booking': BookingModel.objects.get(id=id)}
        data['Payment'] = PaymentDetails.objects.get(Booking=data['Booking'])
        return render(request, 'Bill.html', data)