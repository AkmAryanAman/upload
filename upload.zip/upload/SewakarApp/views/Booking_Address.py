from django.shortcuts import render, redirect
from django.views import View
from SewakarApp.models.Service import ServiceWorker
from SewakarApp.models import SignUp
from SewakarApp.models import WorkStatus
from SewakarApp.models.booking_address import Booking_Address
from SewakarApp.models.booking_model import BookingModel


class BookingAddress(View):
    def get(self, request):
        data = {}
        User = request.session.get('id')
        try:
            cart = None
            if request.session.get('cart'):
                cart = request.session['cart']
        finally:
            pass

        if User:
            if cart:
                data['user'] = SignUp.objects.get(id=User)
                data['pre_address'] = Booking_Address.Get_Address_by_user(data['user'])
                return render(request, 'booking_address.html', data)
            else:
                return redirect('Booking_Form')
        else:
            return redirect('login')

    def post(self, request):

        user = request.session['id']
        state = request.POST.get('State')
        country = request.POST.get('Country')
        address = request.POST.get('Address')
        pincode = request.POST.get('PinCode')

        User = SignUp.objects.get(id=user)
        if address and state:
            booking_address = Booking_Address(User=User,
                                              Address=address,
                                              State=state,
                                              Country=country,
                                              PinCode=pincode)

            booking_address.register()

            address_1 = Booking_Address.Get_Address_by_user(User)

            cart = request.session['cart']

            Worker = ServiceWorker.objects.get(id=cart['Worker'])
            work_status = WorkStatus.objects.get(id=1)

            bookingModel = BookingModel(User=User,
                                        Quantity=cart['Quantity'],
                                        Duration=cart['Duration'],
                                        Location=address_1.last(),
                                        Date=cart['Date'],
                                        Service=Worker,
                                        Status=work_status,
                                        Amount=0)

            bookingModel.register()

            # Delete Cart from session
            try:
                del request.session['cart']
            finally:
                pass

            return redirect('booking')
        else:
            error = "Enter Valid Address.."
            return render(request, 'booking_address.html', {'error': error})


def BookingOnPreviousAddress(request):
    user = request.session.get('id')
    User = SignUp.objects.get(id=user)

    address = request.POST.get('Address_Id')
    Address = Booking_Address.objects.get(id=address)

    cart = request.session['cart']

    Quantity = cart['Quantity']
    Duration = cart['Duration']
    Date = cart['Date']
    Worker = ServiceWorker.objects.get(id=cart['Worker'])
    work_status = WorkStatus.objects.get(id=1)

    bookingModel = BookingModel(User=User,
                                Quantity=Quantity,
                                Duration=Duration,
                                Location=Address,
                                Date=Date,
                                Service=Worker,
                                Status=work_status,
                                Amount=0)

    bookingModel.register()

    # Delete Cart from session
    try:
        del request.session['cart']
    finally:
        pass

    return redirect('booking')


def DeletePreviousAddress(request):
    address = request.POST.get('Address_Id')
    Booking_Address.objects.get(id=address).delete()

    return redirect('Booking_Address')
