from django.shortcuts import render, redirect
from django.views import View
from SewakarApp.models.Service import ServiceDomain, ServiceSubDomain, ServiceWorker, ServiceContractor
from SewakarApp.models import SignUp, WorkStatus
from SewakarApp.models import Booking_Address, Booking_Contractor


class BookingForm(View):
    def get(self, request):
        data = {}

        User = request.session.get('id')

        if User:
            data['user'] = SignUp.objects.get(id=User)
            data['Domain'] = ServiceDomain.get_all_services()

            Sector = request.GET.get('sector')

            if Sector:
                Domain = ServiceDomain.objects.get(id=Sector)
                data['sector'] = Domain
                data['SubDomain'] = ServiceSubDomain.get_all_SubDomain_By_Domain(Domain)
                try:
                    if 'Worker' in data.keys():
                        data.pop('Worker')
                finally:
                    pass

                Service = request.GET.get('service')
                if Service:
                    SubDomain = ServiceSubDomain.objects.get(id=Service)
                    data['service'] = SubDomain
                    data['Worker'] = ServiceWorker.get_all_Worker_By_SubDomain(SubDomain)
                    return render(request, 'booking_form.html', data)

                else:
                    return render(request, 'booking_form.html', data)

            else:
                return render(request, 'booking_form.html', data)

        else:
            return redirect('login')

    def post(self, request):
        Quantity = request.POST.get('Quantity')
        Duration = request.POST.get('Duration')
        Date = request.POST.get('Date')
        Sector = request.POST.get('Sector')
        Service = request.POST.get('Service')
        Worker = request.POST.get('Worker')

        cart = {'Quantity': Quantity,
                'Duration': Duration,
                'Date': Date,
                'Sector': Sector,
                'Service': Service,
                'Worker': Worker}

        request.session['cart'] = cart
        return redirect('Booking_Address')


class BookingContractor(View):
    def get(self, request):
        service = request.GET.get('Service')
        SubDomain = ServiceSubDomain.objects.get(id=service)
        data = {'Contractor': ServiceContractor.objects.filter(SubDomain=SubDomain),
                'SubDomain': SubDomain.SubDomain}

        value = 0
        for x in data['Contractor']:
            value +=1

        if value == 0:
            data['Contractor'] = False

        return render(request, 'Contractor.html', data)

    def post(self, request):
        user = request.session['id']
        user = SignUp.objects.get(id=user)
        address = request.POST.get('Address')
        state = request.POST.get('State')
        country = request.POST.get('Country')
        pincode = request.POST.get('Pin')
        print(address, state, country, pincode)

        book_address = Booking_Address(User=user,
                                       Address=address,
                                       State=state,
                                       Country=country,
                                       PinCode=pincode)

        book_address.register()

        address_1 = Booking_Address.Get_Address_by_user(user)

        contractor = request.POST.get('Contractor')
        contractor = ServiceContractor.objects.get(id=contractor)

        duration = request.POST.get('Duration')
        date = request.POST.get('Date')
        work_status = WorkStatus.objects.get(id=1)

        print(contractor, duration, date)
        bookingContractor = Booking_Contractor(User=user,
                                               Quantity=0,
                                               Duration=duration,
                                               Location=address_1.last(),
                                               Date=date,
                                               Service=contractor,
                                               Status=work_status,
                                               Amount=0)

        bookingContractor.register()

        return redirect('booking')
