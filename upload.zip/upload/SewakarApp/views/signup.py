import json

from django.http import JsonResponse
from django.shortcuts import render, redirect
from django.contrib.auth.hashers import make_password
from SewakarApp.models.signup import SignUp, Category
from django.views import View


class Signup(View):
    def get(self, request):
        Id = request.GET.get('id')
        if Id and Id == '2':
            pass
        else:
            try:
                if request.session['id']:
                    return redirect('main')
            except:
                return render(request, "signup.html")
        return render(request, "signup.html", {'id': Id})

    def post(self, request):
        postData = request.POST
        first_name = postData.get('first_name').upper()
        last_name = postData.get('last_name').upper()
        mobile = postData.get('mobile')
        email = postData.get('email').lower()
        password = postData.get('password')
        cpassword = postData.get('cpassword')
        category = postData.get('category')
        category_instance = Category.objects.get(id=category)

        error_massage = None
        if password == cpassword:
            password = make_password(password)
        else:
            error_massage = 'Confirm Password not same as Password'

        # category = Category.objects.get(id=category)
        # value
        value = {'first_name': first_name,
                 'last_name': last_name,
                 'mobile': mobile,
                 'email': email}

        signup = SignUp(First_name=first_name,
                        Last_name=last_name,
                        Mobile=mobile,
                        Email=email,
                        Password=password,
                        Category=category_instance
                        )

        error_massage = self.validatesignup(signup, error_massage)

        # save
        if not error_massage:
            signup.register()
            return redirect('login')

        else:
            data = {
                'error': error_massage,
                'values': value
            }
            return render(request, 'signup.html', data)

    def validatesignup(self, signup, error_massage):
        # validation

        if len(signup.Mobile) < 10:
            error_massage = 'Enter valid mobile number'

        if signup.isExists():
            error_massage = 'This Email have Already Registered An Account ..'

        return error_massage


def Work_with_us(request):
    fname = request.GET.get('f_name', None)
    lname = request.GET.get('l_name', None)
    email = request.GET.get('email', None)
    mobile = request.GET.get('mobile', None)
    if email:
        data = {}
        is_taken = SignUp.objects.filter(Email__iexact=email).exists()
        if is_taken:
            category_instance = Category.objects.get(id=2)
            user = SignUp.objects.get(Email=email)
            user.Category = category_instance
            user.save()
            data['user'] = True

        else:
            category_instance = Category.objects.get(id=2)
            password = make_password('Sewakar@12345')
            signup = SignUp(First_name=fname,
                            Last_name=lname,
                            Mobile=mobile,
                            Email=email,
                            Password=password,
                            Category=category_instance)

            signup.register()

            user = SignUp.objects.get(Email=email)
            data['user'] = True
    return JsonResponse(data)