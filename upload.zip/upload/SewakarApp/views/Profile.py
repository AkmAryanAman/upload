from django.shortcuts import render, redirect
from SewakarApp.models import SignUp
from django.contrib.auth.hashers import check_password, make_password
from django.views import View
from SewakarApp.models.basic_details import BasicDetails
from SewakarApp.models.Service import ServiceDomain, ServiceSubDomain, ServiceWorker
from SewakarApp.models.Profession import WorkDetail
from SewakarApp.models.user_address import UserAddress


class Profile(View):
    def get(self, request):
        Id = request.session.get('id')
        if Id:
            data = {'Account_Info': SignUp.objects.get(id=Id),
                    'Error_msg': request.GET.get('Error_msg'),
                    'Confirm_msg': request.GET.get('Confirm_msg')}

            if data['Account_Info'].Category.id == 2:
                data['Sector'] = ServiceDomain.get_all_services()
                data['Basic_Details'] = BasicDetails.get_Basic_Details_by_user(data['Account_Info'])
                data['Work_Details'] = WorkDetail.Get_Details_By_user(data['Account_Info'])
                data['Address_Details'] = UserAddress.Get_Address_By_User(data['Account_Info'])
                #data['State'] = State.objects.all()

                if request.GET.get('Sector'):
                    sector = request.GET.get('Sector')
                    data['Domain'] = ServiceDomain.objects.get(id=sector)
                    data['Service'] = ServiceSubDomain.get_all_SubDomain_By_Domain(data['Domain'])

                    if request.GET.get('Service'):
                        service = request.GET.get('Service')
                        data['SubDomain'] = ServiceSubDomain.objects.get(id=service)
                        data['Work'] = ServiceWorker.get_all_Worker_By_SubDomain(data['SubDomain'])

                if request.GET.get('State'):
                    state = request.GET.get('State')
                    if state != '0':
                        pass
                        #data['state'] = State.objects.get(id=state)
                        #data['District'] = District.Get_District_By_State(data['state'])
                return render(request, 'Profile.html', data)
            else:
                return render(request, 'Profile.html', data)

        else:
            return redirect('login')

    def post(self, request):
        pass


def Update_Basic_Details(request):
    id = request.session.get('id')
    if id:
        User = SignUp.objects.get(id=id)
        Get = BasicDetails.get_Basic_Details_by_user(User)
        if Get:
            error_msg = "You have already update your basic details...Please Contact to Manager"
            return redirect('/profile?Error_msg=You have already update your basic details...Please Contact to Manager')
        else:
            father = request.POST.get('Father_name')
            mother = request.POST.get('Mother_name')
            dob = request.POST.get('DOB')
            gender = request.POST.get('Gender')
            blood = request.POST.get('Blood_Group')
            adhar = request.POST.get('Adhar')

            Basic = BasicDetails(User=User,
                                 Father=father,
                                 Mother=mother,
                                 DOB=dob,
                                 Gender=gender,
                                 Blood_Group=blood,
                                 Aadhar=adhar)

            Basic.register()
            return redirect('/profile?Confirm_msg=Basic Details Update Successfully..')
    else:
        return redirect('login')


def Update_Password(request):
    id = request.session.get('id')
    if id:
        User = SignUp.objects.get(id=id)
        old = request.POST.get('old')
        new = request.POST.get('new')
        confirm = request.POST.get('confirm')

        if new == confirm:
            if check_password(old, User.Password):
                User.Password = make_password(new)
                User.save()
                return redirect('/profile?Confirm_msg=Password Update Successfully..')
            else:
                return redirect('/profile?Error_msg=You have entered wrong password..')
        else:
            return redirect('/profile?Error_msg=Confirm Password is not Same as Password..')
    else:
        return redirect('login')


def UpdateWork(request):
    id = request.session.get('id')
    if id:
        User = SignUp.objects.get(id=id)
        if request.POST.get('Work'):
            work = request.POST.get('Work')
            if work == '0':
                return redirect('/profile?Error_msg=Error In Adding....')
            else:
                Work = ServiceWorker.objects.get(id=work)
                domain = request.POST.get('Domain')
                Domain = ServiceDomain.objects.get(id=domain)
                Update_Work = WorkDetail(User=User,
                                         Domain=Domain,
                                         Work=Work)

                Update_Work.register()
                return redirect('/profile?Confirm_msg=Updating your profession successful...')
        else:
            return redirect('/profile?Error_msg=Error In Adding....')
    else:
        return redirect('login')


def RemoveWork(request):
    id = request.session.get('id')
    if id:
        User = SignUp.objects.get(id=id)

        if request.POST.get('Work'):
            work = request.POST.get('Work')
            Work = WorkDetail.objects.get(id=work)
            Work.delete()

        return redirect('/profile?Confirm_msg=Successfully remove skill from your profile....')
    else:
        return redirect('login')


def Update_Address(request):
    id = request.session.get('id')
    if id:
        User_name = SignUp.objects.get(id=id)
        District_id = request.POST.get('District')
        if District_id == '0':
            return redirect('/profile?Error_msg= Please Enter your state and District correctly....')
        else:
            #district = District.objects.get(id=District_id)
            Pin_code = request.POST.get('Pin_Code')
            if Pin_code == None:
                return redirect('/profile?Error_msg= Please Enter Pin Number ....')
            else:
                address_1 = request.POST.get('Address_1')
                address_2 = request.POST.get('Address_2')

                update = UserAddress(User=User_name,
                                     Address_1=address_1,
                                     Address_2=address_2,
                                     #District=district,
                                     PinCode=Pin_code)

                update.register()
                return redirect('/profile?Confirm_msg= Your Address update successfully.....')

        return redirect('profile')
    else:
        return redirect('login')
