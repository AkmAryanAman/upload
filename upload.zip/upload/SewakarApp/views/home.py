from django.shortcuts import render, redirect
from django.views import View

from SewakarApp.models.Service import ServiceDomain


class Index(View):
    def get(self, request):

        data = {'Domain': ServiceDomain.objects.all()}

        '''dataJSON = json.dumps(data['Domain'])   {'data': dataJSON}'''
        return render(request, "index.html", data)

    def post(self, request):
        return redirect('home')

