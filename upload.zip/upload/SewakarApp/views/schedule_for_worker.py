from django.shortcuts import render, redirect
from django.views import View
from SewakarApp.models.booking_model import Scheduling
from SewakarApp.models.signup import SignUp



class Schedule_List_For_Worker(View):
    def get(self, request):
        User = request.session.get('id')
        if User:
            data = {'user': SignUp.objects.get(id=User)}
            data['Schedule'] = Scheduling.objects.filter(Worker=data['user']).order_by('-Booking')

            return render(request, 'Schedule_for_Worker.html', data)

        return redirect('login')

    def post(self, request):
        pass