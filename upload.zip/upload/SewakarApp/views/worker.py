from django.shortcuts import render, redirect
from SewakarApp.models.signup import SignUp, Category, Worker_Status_Name, Worker_Current_Status
from SewakarApp.models.user_address import UserAddress
from SewakarApp.models.Profession import WorkDetail
from SewakarApp.models.basic_details import BasicDetails
from SewakarApp.models.feedback import Work_With_us
from django.views import View
import datetime


class Worker(View):
    def get(self, request):
        category = Category.objects.get(id=2)
        data = {'worker': SignUp.objects.filter(Category=category),
                'Application': Work_With_us.objects.all().order_by('-id'),
                'verified_worker_list': Worker_Current_Status.objects.all(),
                'Address': UserAddress.objects.all(),
                'Work_Details': WorkDetail.objects.all(),
                'Basic_Details': BasicDetails.objects.all()}
        print(data['Application'])

        return render(request, 'Worker.html', data)

    def post(self, request):
        return redirect('worker')


def Verify_Worker(request):
    if request.POST.get('Worker_id'):
        worker_id = request.POST.get('Worker_id')
        worker = SignUp.objects.get(id=worker_id)
        Status = Worker_Status_Name.objects.get(id=1)
        verify = Worker_Current_Status(User=worker,
                                       Status=Status,
                                       Date=datetime.date.today())

        verify.register()
    return redirect('worker')
