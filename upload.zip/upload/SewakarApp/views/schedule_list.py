from django.shortcuts import render, redirect
from SewakarApp.models.booking_model import Scheduling
from django.views import View


class Schedule_List(View):
    def get(self, request):
        data = {'Schedule': Scheduling.objects.all().order_by('Booking')}
        return render(request, 'Schedule_List.html', data)

    def post(self, request):
        return redirect('worker')
