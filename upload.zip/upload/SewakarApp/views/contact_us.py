from django.shortcuts import render, redirect

from SewakarApp.models import ServiceDomain, ServiceSubDomain
from SewakarApp.models.Service import ServiceWorker
from SewakarApp.models.feedback import Feedback, Query, Work_With_us
from django.views import View
import datetime


class ContactUs(View):
    def get(self, request):
        data = {'Feedback': Feedback.objects.all().order_by('-id')}
        return render(request, "contact_us.html", data)

    def post(self, request):
        form = request.POST.get('Form')
        if form == 'Feedback':
            Name = request.POST.get('Name')
            Email = request.POST.get('Email')
            feedback = request.POST.get('Feedback')

            if feedback:
                feedback = Feedback(Name=Name,
                                    Email=Email,
                                    Feedback=feedback)

                feedback.register()

        if form == 'Query':
            Name = request.POST.get('Name')
            Email = request.POST.get('Email')
            Subject = request.POST.get('Subject')
            query = request.POST.get('Query')

            if Subject and query:
                Submit_Query = Query(Name=Name,
                                     Email=Email,
                                     Subject=Subject,
                                     Query=query)

                Submit_Query.register()

        if form == 'Work_With_Us':
            Name = request.POST.get('Name')
            Mobile = request.POST.get('Mobile')
            Sector = request.POST.get('Sector')
            Sector = ServiceDomain.objects.get(id=Sector)

            Service = request.POST.get('Service')
            Service = ServiceSubDomain.objects.get(id=Service)

            Worker = request.POST.get('Worker')
            Worker = ServiceWorker.objects.get(id=Worker)

            msg = 'I am ' + Name + ', Mobile no. - ' + Mobile + '. I request for work service in =>' + \
                  Sector.Domain + ' / ' + Service.SubDomain + ' / ' + Worker.Worker

            print(msg)
            if Mobile and Service:
                Submit_Query = Query(Name=Name,
                                     Email=Mobile,
                                     Subject='Service Request',
                                     Query=msg,
                                     Type=2)

                Submit_Query.register()

            return redirect('/work_with_us?Confirm_msg=You Request accepted')

        return redirect('contact_us')


class Work_with_us(View):
    def get(self, request):
        data = {'Error_msg': request.GET.get('Error_msg'),
                'Confirm_msg': request.GET.get('Confirm_msg')}
        return render(request, "work_with_us.html", data)

    def post(self, request):
        post = request.POST
        F_name = post.get('F_name')
        L_name = post.get('L_name')
        DOB = datetime.datetime.strptime(post.get('DOB'), "%Y-%m-%d").date()
        Mobile = int(post.get('Mobile'))
        data = {'Error_msg': ''}

        if not Mobile:
            data['Error_msg'] = 'Enter Mobile Number'

        Email = post.get('Email')
        if not Email:
            Email = 'Not Available'

        Adhar = int(post.get('Adhar'))
        if not Adhar:
            data['Error_msg'] = 'Enter Adhar Number'

        Address = post.get('Address')
        if not Address:
            data['Error_msg'] = 'Enter valid Address'

        State = post.get('State')
        if not State:
            data['Error_msg'] = 'Enter valid State Name'

        PinCode = int(post.get('PinCode'))
        if not PinCode:
            data['Error_msg'] = 'Enter valid PinCode'

        Education = post.get('Education')
        if not Education:
            data['Error_msg'] = 'Select Qualification'

        Skills = post.get('Skills')
        if not Skills:
            data['Error_msg'] = 'Let me about your skills'

        Work_Location = post.get('Work_Location')
        if not Work_Location:
            data['Error_msg'] = 'Select Work Preference'

        Work_State = post.get('Work_State')
        if not Work_State:
            Work_State = 'Not in Choice'

        Work_Area = post.get('Work_Area')
        if not Work_Area:
            Work_Area = 'Not in Choice'

        Experience = post.get('Experience')
        if not Experience:
            Experience = 'No Experience'

        Rate = int(post.get('Rate'))
        if not Rate:
            Rate = 0
        Adhar_Copy = post.get('Adhar_Copy')

        Photo = post.get('Photo')

        if data['Error_msg'] != '':
            data['value'] = {'F_name': F_name,
                             'L_name': L_name,
                             'DOB': DOB,
                             'Mobile': Mobile,
                             'Email': Email,
                             'Adhar': Adhar,
                             'State': State,
                             'PinCode': PinCode,
                             'Skills': Skills,
                             'Work_State': Work_State,
                             'Work_Area': Work_Area,
                             'Experience': Experience,
                             'Rate': Rate}
            return render(request, "work_with_us.html", data)

        else:
            req = Work_With_us(Name=F_name + ' ' + L_name,
                               DOB=DOB,
                               Mobile=Mobile,
                               Email=Email,
                               Adhar=Adhar,
                               Address=Address,
                               State=State,
                               PinCode=PinCode,
                               Qualification=Education,
                               Skills=Skills,
                               Work=Work_Location,
                               Work_State=Work_State,
                               Work_Location=Work_Area,
                               Experience=Experience,
                               Rate=Rate,
                               Adhar_image=Adhar_Copy,
                               Image=Photo)

            req.register()

            return redirect('/work_with_us?Confirm_msg=Your response has been recorded')
