import json

from django.core.serializers.json import DjangoJSONEncoder
from django.forms import model_to_dict
from django.shortcuts import render, redirect
from SewakarApp.models.Service import ServiceSubDomain, ServiceDomain, ServiceWorker
from django.views import View
from django.http import JsonResponse


class AllServices(View):
    def get(self, request):
        data = {'Domain': ServiceDomain.objects.all(),
                'Service': ServiceSubDomain.objects.all().order_by('Domain')}
        return render(request, "service.html", data)

    def post(self, request):
        pass


def All_Service(request, data):
    print('hlo')
    '''data = model_to_dict(ServiceDomain.objects.all(), fields=[], exclude=[])'''
    data = ServiceDomain.objects.all()
    data = json.dumps(data, cls=DjangoJSONEncoder)
    print(data)
    return JsonResponse(data)


