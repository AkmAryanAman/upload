from django.shortcuts import render, redirect
from django.views import View


class Blog(View):
    def get(self, request):
        return render(request,"Blog.html")

    def post(self, request):
        pass
