from django import template

register = template.Library()


@register.filter(name='Check_Payment')
def Check_Payment(all_Payment, Booking):
    for Payment in all_Payment:
        if Payment.Booking == Booking:
            return True
    return False


@register.filter(name='Rate')
def Rate(Amount, Quantity):
    rate = int(Amount) / int(Quantity)
    return rate


@register.filter(name='Check_Status')
def Check_Status(Booking, Status):
    if Booking.Status.Type == Status:
        return True
    else:
        return False
