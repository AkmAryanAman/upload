from django import template

register = template.Library()


@register.filter(name='Check_Domain')
def Check_Domain(Domain, Service):
    if Domain.id == Service.Domain.id:
        return True
    return False