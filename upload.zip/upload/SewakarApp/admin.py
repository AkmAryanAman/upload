from django.contrib import admin
from SewakarApp.models.signup import SignUp, Phone, Category, Worker_Status_Name, Worker_Current_Status
from SewakarApp.models.work_Status import WorkStatus
from SewakarApp.models.Service import ServiceDomain, ServiceSubDomain, ServiceWorker, ServiceContractor
from SewakarApp.models.booking_model import BookingModel, PaymentDetails, Scheduling
from SewakarApp.models.Profession import WorkDetail
from SewakarApp.models.user_address import UserAddress
from SewakarApp.models.basic_details import BasicDetails
from SewakarApp.models.booking_address import Booking_Address
from SewakarApp.models.feedback import Feedback, Query, Comment_Query, Work_With_us
from SewakarApp.models.EmailConfirmation import Confirmation
from SewakarApp.models.contractor import Booking_Contractor, Contractor_Payment


class AdminWork_With_Us(admin.ModelAdmin):
    list_display = ['Name', 'DOB', 'Mobile', 'Email', 'Adhar', 'Address', 'State', 'PinCode',
                    'Qualification', 'Skills', 'Work', 'Work_State', 'Work_Location', 'Experience',
                    'Rate', 'Adhar_image', 'Image']


class AdminConfirmation(admin.ModelAdmin):
    list_display = ['User', 'Code']


class AdminComment(admin.ModelAdmin):
    list_display = ['Query', 'Comment', 'Date']


class AdminQuery(admin.ModelAdmin):
    list_display = ['Name', 'Email', 'Subject', 'Query', 'Type']


class AdminWorker_Current_Status(admin.ModelAdmin):
    list_display = ['User', 'Status', 'Date', 'Points']


class AdminWorker_Status_Name(admin.ModelAdmin):
    list_display = ['Status']


class AdminScheduling(admin.ModelAdmin):
    list_display = ['Booking', 'Worker']


class AdminPayment_Details(admin.ModelAdmin):
    list_display = ['User', 'Booking', 'Amount', 'Reference_No']


class AdminContractor_Payment(admin.ModelAdmin):
    list_display = ['User', 'Booking', 'Amount', 'Reference_No']


class AdminFeedback(admin.ModelAdmin):
    list_display = ['Name', 'Email', 'Feedback']


class AdminServiceContractor(admin.ModelAdmin):
    list_display = ['SubDomain', 'Contractor', 'Address', 'Rating']


class AdminServiceWorker(admin.ModelAdmin):
    list_display = ['SubDomain', 'Worker']


class AdminBookingAddress(admin.ModelAdmin):
    list_display = ['User', 'Address', 'State', 'Country', 'PinCode']


class AdminBasicDetails(admin.ModelAdmin):
    list_display = ['User', 'Father', 'Mother', 'DOB', 'Gender', 'Blood_Group', 'Aadhar']


class AdminUserAddress(admin.ModelAdmin):
    list_display = ['User', 'Address_1', 'Address_2', 'State', 'Country', 'PinCode']


class AdminWorkDetail(admin.ModelAdmin):
    list_display = ['User', 'Domain', 'Work']


class AdminServiceSubDomain(admin.ModelAdmin):
    list_display = ['Domain', 'SubDomain', 'Description']


class AdminPhone(admin.ModelAdmin):
    list_display = ['Mobile']


class AdminCategory(admin.ModelAdmin):
    list_display = ['Type']


class AdminWorkStatus(admin.ModelAdmin):
    list_display = ['Type']


class AdminServiceDomain(admin.ModelAdmin):
    list_display = ['Domain', 'Description']


class AdminSignUp(admin.ModelAdmin):
    list_display = ['First_name', 'Last_name', 'Email', 'Mobile', 'Category', 'Password', 'status']


class AdminBooking(admin.ModelAdmin):
    list_display = ['User', 'Quantity', 'Duration', 'Location', 'Date', 'Service', 'Status', 'Amount']


class AdminBooking_Contractor(admin.ModelAdmin):
    list_display = ['User', 'Quantity', 'Duration', 'Location', 'Date', 'Service', 'Status', 'Amount']


# Register your models here.
admin.site.register(Category, AdminCategory)
admin.site.register(WorkStatus, AdminWorkStatus)
admin.site.register(ServiceDomain, AdminServiceDomain)
admin.site.register(SignUp, AdminSignUp)
admin.site.register(BookingModel, AdminBooking)
admin.site.register(Booking_Contractor, AdminBooking_Contractor)
admin.site.register(ServiceSubDomain, AdminServiceSubDomain)
admin.site.register(Phone, AdminPhone)
admin.site.register(WorkDetail, AdminWorkDetail)
admin.site.register(UserAddress, AdminUserAddress)
admin.site.register(BasicDetails, AdminBasicDetails)
admin.site.register(Booking_Address, AdminBookingAddress)
admin.site.register(ServiceWorker, AdminServiceWorker)
admin.site.register(ServiceContractor, AdminServiceContractor)
admin.site.register(PaymentDetails, AdminPayment_Details)
admin.site.register(Contractor_Payment, AdminContractor_Payment)
admin.site.register(Scheduling, AdminScheduling)
admin.site.register(Worker_Status_Name, AdminWorker_Status_Name)
admin.site.register(Worker_Current_Status, AdminWorker_Current_Status)
admin.site.register(Feedback, AdminFeedback)
admin.site.register(Query, AdminQuery)
admin.site.register(Comment_Query, AdminComment)
admin.site.register(Confirmation, AdminConfirmation)
admin.site.register(Work_With_us, AdminWork_With_Us)
