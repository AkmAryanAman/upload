from django import template

register = template.Library()


@register.filter(name='Check_Payment')
def Check_Payment(all_Payment, Booking):
    for Payment in all_Payment:
        if Payment.Booking == Booking:
            return True
    return False
