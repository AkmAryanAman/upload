from django.shortcuts import render, redirect
from SewakarApp.models.Service import ServiceSubDomain, ServiceDomain
from django.views import View


class AllServices(View):
    def get(self, request):
        data = {'Service': ServiceSubDomain.objects.all().order_by('Domain')}
        domain = request.GET.get('sector')
        if domain:
            Domain = ServiceDomain.objects.get(id=domain)
            data = {'Service': ServiceSubDomain.objects.filter(Domain=Domain)}
        return render(request, "service.html", data)

    def post(self, request):
        pass

