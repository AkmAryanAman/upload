from django.shortcuts import render, redirect
from django.views import View
from SewakarApp.models.booking_model import BookingModel, Scheduling


class Booking_List(View):
    def get(self, request):
        data = {'Booking_List': BookingModel.objects.all(),
                'Schedule': Scheduling.objects.all()}
        return render(request, 'Booking_list.html', data)

    def post(self, request):
        return redirect('Booking_List')