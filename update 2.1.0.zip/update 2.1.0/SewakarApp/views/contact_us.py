from django.shortcuts import render, redirect
from SewakarApp.models.feedback import Feedback, Query
from django.views import View


class ContactUs(View):
    def get(self, request):
        data = {'Feedback': Feedback.objects.all().order_by('-id')}
        return render(request, "contact_us.html", data)

    def post(self, request):
        form = request.POST.get('Form')
        if form == 'Feedback':
            Name = request.POST.get('Name')
            Email = request.POST.get('Email')
            feedback = request.POST.get('Feedback')

            if feedback:
                feedback = Feedback(Name=Name,
                                    Email=Email,
                                    Feedback=feedback)

                feedback.register()

        if form == 'Query':
            Name = request.POST.get('Name')
            Email = request.POST.get('Email')
            Subject = request.POST.get('Subject')
            query = request.POST.get('Query')

            if Subject and query:
                Submit_Query = Query(Name=Name,
                                     Email=Email,
                                     Subject=Subject,
                                     Query=query)

                Submit_Query.register()


        return redirect('contact_us')
