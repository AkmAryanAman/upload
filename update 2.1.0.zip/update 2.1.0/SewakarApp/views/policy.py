from django.shortcuts import render
from django.views import View


class Policy(View):
    def get(self, request):
        return render(request, "policy.html")

    def post(self, request):
        pass

