from django.db import models
from .signup import SignUp
from .location import State, District


# This module collect the booking Address
class Booking_Address(models.Model):
    User = models.ForeignKey(SignUp, on_delete=models.CASCADE, default='')
    Address = models.CharField(max_length=200, default='')
    District = models.ForeignKey(District, on_delete=models.CASCADE, default='')
    PinCode = models.IntegerField()

    def register(self):
        self.save()

    # this function return the address by user
    @staticmethod
    def Get_Address_by_user(User):
        try:
            result = False
            if Booking_Address.objects.filter(User=User):
                result = Booking_Address.objects.filter(User=User)
            else:
                pass
        finally:
            return result
