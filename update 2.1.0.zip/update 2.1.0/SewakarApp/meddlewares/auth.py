from django.shortcuts import redirect
from django.urls import get_resolver


def auth_middleware(get_response):
    # One-time configuration and initialization

    def middleware(request):
        returnUrl = request.get_full_path()
        if not request.session.get('id'):
            return redirect(f'/login?return_url={returnUrl}')
        response = get_response(request)
        return response

    return middleware


def category_middleware(get_response):
    # One-time configuration and initialization

    def middleware(request):
        returnUrl = request.META['PATH_INFO']
        if request.session.get('id'):
            category = request.session.get('category')
            if int(category) != 3:
                return redirect('main')
        else:
            return redirect(f'login?return_url={returnUrl}')

        response = get_response(request)

        return response

    return middleware
