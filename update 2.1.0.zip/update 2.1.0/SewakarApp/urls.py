from django.urls import path
from .meddlewares.auth import auth_middleware, category_middleware
from SewakarApp.views import help_center, about_us, contact_us
from SewakarApp.views import login, home, worker, Profile, signup, services
from SewakarApp.views import Booking_Cart, Booking_Address, Booking_Form
from SewakarApp.views import SearchWorker, Booking_list, schedule_list
from SewakarApp.views import schedule_for_worker, policy

urlpatterns = [
    path('', home.Index.as_view(), name='main'),
    path('signup', signup.Signup.as_view(), name='signup'),
    path('login', login.Login.as_view(), name='login'),
    path('service', services.AllServices.as_view(), name='service'),

    path('profile', auth_middleware(Profile.Profile.as_view()), name='profile'),
    path('profile/Update_Password', auth_middleware(Profile.Update_Password), name='Update_Password'),
    path('profile/Update_Basic_Details', auth_middleware(Profile.Update_Basic_Details), name='Update_Basic_Details'),
    path('profile/Update_Work', auth_middleware(Profile.UpdateWork), name='Update_Work'),
    path('profile/Remove_Work', auth_middleware(Profile.RemoveWork), name='Remove_Work'),
    path('profile/Update_Address', auth_middleware(Profile.Update_Address), name='Update_Address'),

    path('booking', auth_middleware(Booking_Cart.Booking.as_view()), name='booking'),
    path('booking/Booking_Form', auth_middleware(Booking_Form.BookingForm.as_view()), name='Booking_Form'),
    path('booking/Booking_Address', auth_middleware(Booking_Address.BookingAddress.as_view()), name='Booking_Address'),
    path('booking/Booking_Address/Previous_Address', auth_middleware(Booking_Address.BookingOnPreviousAddress),
         name='Booking_On_Address'),
    path('booking/Booking_Address/Delete_Address', auth_middleware(Booking_Address.DeletePreviousAddress),
         name='Remove_Address'),

    path('worker', category_middleware(worker.Worker.as_view()), name='worker'),
    path('worker/Verify_Worker', category_middleware(worker.Verify_Worker), name='Verify_Worker'),

    path('Booking_List', category_middleware(Booking_list.Booking_List.as_view()), name='Booking_List'),
    path('Booking_List/Search_Worker', category_middleware(SearchWorker.Search_Worker.as_view()), name='Search_Worker'),
    path('Booking_List/Search_Worker/Update_Amount', category_middleware(SearchWorker.UpdateAmount),
         name='Update_Amount'),
    path('Booking_List/Search_Worker/Add_Payment', category_middleware(SearchWorker.Add_Payment), name='Add_Payment'),
    path('Booking_List/Search_Worker/Schedule', category_middleware(SearchWorker.Schedule), name='Schedule'),
    path('Booking_List/Search_Worker/Accept_Booking', category_middleware(SearchWorker.AcceptBooking),
         name='Accept_Booking'),
    path('Booking_List/Search_Worker/Delete_Booking', category_middleware(SearchWorker.DeleteBooking),
         name='Delete_Booking'),
    path('Booking_List/Search_Worker/Schedule/Remove_Schedule',
         category_middleware(SearchWorker.Remove_Schedule_Worker),
         name='Remove_Schedule'),

    path('Schedule_List', category_middleware(schedule_list.Schedule_List.as_view()), name='Schedule_List'),

    path('Schedule_List_For_Worker', auth_middleware(schedule_for_worker.Schedule_List_For_Worker.as_view()),
         name='Schedule_List_For_Worker'),

    path('remove', auth_middleware(Booking_Cart.RemoveBooking), name='remove'),
    path('help_center', help_center.HelpCenter.as_view(), name='help_center'),
    path('contact_us', contact_us.ContactUs.as_view(), name='contact_us'),
    path('about_us', about_us.AboutUs.as_view(), name='about_us'),
    path('policy',policy.Policy.as_view(), name='Policy'),
    path('logout', login.logout, name='logout'),
]
