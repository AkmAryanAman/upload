from django.shortcuts import render, redirect
from SewakarApp.models.signup import SignUp, Category, Worker_Current_Status, Worker_Status_Name
from django.views import View
from SewakarApp.models.booking_model import BookingModel, PaymentDetails, Scheduling
from SewakarApp.models.user_address import UserAddress
from SewakarApp.models.Profession import WorkDetail
from SewakarApp.models.work_Status import WorkStatus


class Search_Worker(View):
    def get(self, request):

        Booking_id = request.GET.get('Booking_id')
        if Booking_id:
            category = Category.objects.get(id=2)
            # Get Data About Booking By Booking Id
            data = {'Booking': BookingModel.objects.get(id=Booking_id)}

            # Get Payment Details of Booking
            data['Payment'] = PaymentDetails.Get_Payment_By_Booking(data['Booking'])

            # Filter Worker List By using Booking Location
            worker_using_address = UserAddress.objects.filter(District=data['Booking'].Location.District)

            # Variable to Store Data After filter worker by work
            worker_filter_by_work = []

            # Variable to Store Scheduler worker
            Scheduled_Worker = []

            # Get details about every worker which is already filtered by Location
            for x in worker_using_address:

                # filter worker by using worker_id and Booking Service
                # it may called as filter by service
                filter_1 = WorkDetail.Get_Details_By_user_and_Work(x.User, data['Booking'].Service)

                if filter_1:
                    try:
                        # Getting Current status of worker
                        filter_2 = Worker_Current_Status.objects.get(User=x.User)

                        # these are Status Details
                        Status = Worker_Status_Name.objects.get(id=1)
                        Status3 = Worker_Status_Name.objects.get(id=3)

                        # Checking Status Available or Scheduled
                        if filter_2.Status.id == Status.id:

                            # if Available then put into filtered worker
                            worker_filter_by_work.append(filter_2)

                        elif filter_2.Status.id == Status3.id:

                            # if Schedule than check ... Is is schedule for same booking
                            try:
                                if Scheduling.objects.get(Worker=filter_2.User, Booking=data['Booking']):

                                    # if yes then Put into Scheduled worker
                                    Scheduled_Worker.append(filter_2)
                            except:
                                pass
                    except:
                        pass

            data['Worker_filter'] = worker_filter_by_work
            data['Scheduled_Worker'] = Scheduled_Worker

            return render(request, 'searchworker.html', data)
        else:
            return redirect('Booking_List')

    def post(self, request):
        return redirect('worker')


def UpdateAmount(request):
    if request.POST.get('Booking_id'):
        Booking_id = request.POST.get('Booking_id')
        Amount = request.POST.get('Add_Amount')

        Booking = BookingModel.objects.get(id=Booking_id)
        Booking.Amount = Amount
        Booking.save()

    return redirect('Search_Worker')


def Add_Payment(request):
    if request.POST.get('Booking_id'):
        Booking_id = request.POST.get('Booking_id')
        Referal = request.POST.get('Reference_No')
        Amount = request.POST.get('Amount')

        Booking = BookingModel.objects.get(id=Booking_id)
        payment = PaymentDetails(User=Booking.User,
                                 Booking=Booking,
                                 Reference_No=Referal,
                                 Amount=Amount)

        payment.register()
    return redirect('Search_Worker')


def Schedule(request):
    if request.POST.get('Booking_id'):
        Booking_id = request.POST.get('Booking_id')
        Worker = request.POST.get('Worker')

        Booking = BookingModel.objects.get(id=Booking_id)
        worker = SignUp.objects.get(id=Worker)

        try:
            Worker_Status = Worker_Current_Status.objects.get(User=worker)
            Status = Worker_Status_Name.objects.get(id=3)
            Worker_Status.Status = Status
            Worker_Status.save()
        except:
            pass

        schedule = Scheduling(Booking=Booking,
                              Worker=worker)

        schedule.register()

        Get_Schedule = Scheduling.objects.filter(Booking=Booking)
        count = 0
        for x in Get_Schedule:
            count += 1
        if count == Booking.Quantity:
            work_Status = WorkStatus.objects.get(id=3)
            Booking.Status = work_Status
            Booking.save()

    return redirect('Search_Worker')


def Remove_Schedule_Worker(request):
    if request.POST.get('User_id'):
        User = SignUp.objects.get(id=request.POST.get('User_id'))
        Booking = BookingModel.objects.get(id=request.POST.get('Booking_id'))
        schedule = Scheduling.objects.get(Booking=Booking, Worker=User)
        try:
            Worker_Status = Worker_Current_Status.objects.get(User=User)
            Status = Worker_Status_Name.objects.get(id=1)
            Worker_Status.Status = Status
            Worker_Status.save()
        except:
            pass

        schedule.delete()

        Get_Schedule = Scheduling.objects.filter(Booking=Booking)
        count = 0
        for x in Get_Schedule:
            count += 1

        if count != Booking.Quantity:
            work_Status = WorkStatus.objects.get(id=2)
            Booking.Status = work_Status
            Booking.save()

    return redirect('Search_Worker')


def AcceptBooking(request):
    if request.POST.get('Booking_id'):
        Booking_id = request.POST.get('Booking_id')

        Booking = BookingModel.objects.get(id=Booking_id)
        Status = WorkStatus.objects.get(id=2)
        Booking.Status = Status
        Booking.save()
    return redirect('Search_Worker')


def DeleteBooking(request):
    if request.POST.get('Booking_id'):
        Booking_id = request.POST.get('Booking_id')
        Booking = BookingModel.objects.get(id=Booking_id)
        worker_list = Scheduling.objects.filter(Booking=Booking)
        for worker in worker_list:
            current_status = Worker_Current_Status.objects.get(User=worker.Worker)
            Status = Worker_Status_Name.objects.get(id=1)
            current_status.Status = Status
            current_status.save()

        Booking.delete()

    return redirect('Search_Worker')
