from django.shortcuts import render, redirect, HttpResponseRedirect
from django.contrib.auth.hashers import check_password, make_password
from SewakarApp.models import SignUp
from SewakarApp.models.EmailConfirmation import Confirmation
from django.views import View
from random import randrange
from django.http import JsonResponse
from smtplib import SMTP
import datetime


class Login(View):
    return_url = None
    service = None

    def get(self, request):
        Login.return_url = request.GET.get('return_url')
        Login.service = request.GET.get('service')

        data = {'Confirm_msg': request.GET.get('Confirm_msg')}

        session_id = request.session.get('id')
        if session_id:
            return redirect('profile')
        else:
            if request.GET.get('return_url'):
                Login.return_url = request.GET.get('return_url')
            return render(request, "login.html", data)

    def post(self, request):
        email = request.POST.get('email').lower()
        password = request.POST.get('password')
        People = SignUp.get_people_by_email(email)

        error_massage = None
        if People:
            flag = check_password(password, People.Password)
            if flag:
                if People.status:
                    request.session['id'] = People.id
                    request.session['first_name'] = People.First_name
                    request.session['last_name'] = People.Last_name
                    request.session['category'] = People.Category.id
                    if People.Category.id == 3:
                        request.session['Admin'] = People.Category.id
                    if People.Category.id == 2:
                        request.session['Worker'] = People.Category.id
                    if Login.return_url:
                        if Login.service:
                            return HttpResponseRedirect(f'{Login.return_url}&service={Login.service}')
                        return HttpResponseRedirect(Login.return_url)
                    else:
                        Login.return_url = None
                        Login.sector = None
                        Login.service = None
                        return redirect('main')
                else:
                    request.session['email'] = People.Email
                    return redirect('Activate_Account')
            else:
                error_massage = 'Entered Password is invalid !!'
        else:
            error_massage = 'Email or Password invalid !!'

        return render(request, "login.html", {'error': error_massage, 'email': email})


def validate_email(request):
    email = request.GET.get('email', None)
    data = {
        'is_taken': SignUp.objects.filter(Email__iexact=email).exists()
    }
    return JsonResponse(data)


def logout(request):
    request.session.clear()
    return redirect('main')


def Activate_Account(request):
    massage = {'Error_msg': request.GET.get('Error_msg'),
               'Confirm_msg': request.GET.get('Confirm_msg')}

    Get_Code = request.GET.get('Activated_Link')
    Reset_Pass = request.GET.get('ResetPassword')
    Get_user = request.GET.get('Email')
    Email_on_login = request.POST.get('Email')
    Reset = request.POST.get('Reset')
    if Get_Code:
        user = Confirmation.Confirm_Code(Get_user, Get_Code)
        if user:
            User = user.User
            User.status = True
            User.save()
            Confirmation.objects.get(User=user).delete()
            return redirect('login?Confirm_msg=Your account verified successfully....thank you')
        return redirect('Activate_Account?Error_msg=Please Enter valid Link....Thank You')

    if Reset_Pass:
        user = Confirmation.Confirm_Code(Get_user, Reset_Pass)
        if user:
            User = user.User
            x = randrange(10000, 99999)
            passw = 'Sewakar@' + x
            password = make_password(passw)
            User.Password = password
            User.save()
            Confirmation.objects.get(User=user).delete()
            return redirect(f'login?Confirm_msg=Your default password is {passw}')
        return redirect('Activate_Account?Error_msg=Please Enter valid Link....Thank You')

    if Email_on_login:
        code_valide = randrange(10000)
        user = SignUp.objects.get(Email=Email_on_login)

        if not Confirmation.Get_Code_By_User(user):
            confirm = Confirmation(User=user,
                                   Code=code_valide)
            confirm.register()

        debuglevel = 0
        smtp = SMTP()
        smtp.set_debuglevel(debuglevel)
        smtp.connect('smtp.hostinger.com', 587)
        smtp.login('support@sewakar.com', 'Aryan@1234')
        from_addr = 'Sewakar - Skilled Staff Service<support@sewakar.com>'
        to_addr = Email_on_login
        sub = 'Email verification link'
        date = datetime.datetime.now()

        verification_code = Confirmation.Get_Code_By_User(user)
        if Reset:
            mail_text = f"Your verification Link is http://www.sewakar.com/Activate_Account?" \
                        f"ResetPassword={verification_code.Code}&Email={to_addr}"

            msg = f'From:{from_addr}\nTo:{to_addr}\nSubject:{sub}\nDate:{date}\n\n\n{mail_text}'
            smtp.sendmail(from_addr, to_addr, msg)
            smtp.quit()

            return redirect(
                f'login?Confirm_msg=Your Reset Password link will be send on your '
                f'Email at '
                f'{Email_on_login}'
            )

        else:
            mail_text = f"Your verification Link is http://www.sewakar.com/Activate_Account?" \
                        f"Activated_Link={verification_code.Code}&Email={to_addr}"

            msg = f'From:{from_addr}\nTo:{to_addr}\nSubject:{sub}\nDate:{date}\n\n\n{mail_text}'
            smtp.sendmail(from_addr, to_addr, msg)
            smtp.quit()

            request.session.clear()

        return redirect(
            f'Activate_Account?Confirm_msg=Your Confirmation massage will be send in 24 h on your registered '
            f'Email at '
            f'{Email_on_login}'
        )

    return render(request, 'activate_account.html', massage)


def Send_Activation_Email(request):
    debuglevel = 0
    smtp = SMTP()
    smtp.set_debuglevel(debuglevel)
    smtp.connect('smtp.hostinger.com', 587)
    smtp.login('ak@sewakar.com', 'Aryan@1234')
    from_addr = 'Sewakar<support@sewakar.com>'
    to_addr = request.session['email']
    sub = 'Email verification link'
    date = datetime.datetime.now()

    user = SignUp.objects.get(Email=to_addr)
    verification_code = Confirmation.objects.get(user)
    mail_text = f"Your verification Link is http://www.sewakar.com/Activate_Account?Activated_Link={verification_code}"

    msg = f'From:{from_addr}\nTo:{to_addr}\nSubject:{sub}\nDate:{date}\nMassage:{mail_text}'
    smtp.sendmail(from_addr, to_addr, msg)
    smtp.quit()

    request.session.clear()
    return redirect('login')
