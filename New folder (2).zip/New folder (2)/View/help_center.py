from django.shortcuts import render, redirect
from SewakarApp.models.feedback import Query, Comment_Query
from django.views import View


class HelpCenter(View):
    def get(self, request):
        Query_get = request.GET.get('Query')
        if Query_get:
            Query_get = Query_get.lower()
            remove = ['what', 'how', 'when', 'is', 'am', 'are', 'to']
            Word = Query_get.split()
            for x in remove:
                if x in Word:
                    Word.remove(x)

            for x in Word:
                data = {'Query': Query.objects.filter(Query__contains=x),
                        'Comment': Comment_Query.objects.all()}
                return render(request, "help_center.html", data)

        data = {'Query': Query.objects.all().order_by('-id'),
                'Comment': Comment_Query.objects.all()}
        return render(request, "help_center.html", data)

    def post(self, request):
        pass
