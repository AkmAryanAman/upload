from django import template

register = template.Library()


@register.filter(name='Check_Category')
def Check_Category(User_id, Check_id):
    if int(User_id) == int(Check_id):
        return True
    return False


@register.filter(name='Check_Count')
def Check_Count(arg, validation):
    count = 0
    for x in arg:
        count += 1

    if count < 3:
        return True
    else:
        return False


@register.filter(name='Check_Status')
def Check_Status(Booking_Status, value):
    if Booking_Status.Type == value:
        return True
    else:
        return False


@register.filter(name='Complete_Schedule')
def Complete_Schedule(Booking, Scheduling):
    count = 0
    for schedule in Scheduling:
        if Booking == schedule.Booking:
            count += 1

    if count == Booking.Quantity:
        return True
    else:
        return False


@register.filter(name='If_Complete_Schedule')
def If_Complete_Schedule(Booking, Scheduling):
    count = 0
    for schedule in Scheduling:
        count += 1

    if count == Booking.Quantity:
        return False
    else:
        return True


@register.filter(name='Verified_Worker')
def Verified_Worker(verified_list, Worker):
    for x in verified_list:
        if x.User == Worker:
            return True
    return False


@register.filter(name='Find_Address')
def Find_Address(All, worker):
    for Address in All:
        if Address.User == worker:
            return Address
        else:
            return 'NA'


@register.filter(name='Get_Address')
def Get_Address(All, Worker):
    for Address in All:

        if Address.User == Worker:
            result = str(Address.Address_1) + ', ' + str(
                Address.Address_2) + ",  District -" + Address.District.District + ',  State - ' + Address.District.State.State + ',  PinCode - ' + str(
                Address.PinCode)
            return result
    return 'NA'


@register.filter(name='Get_Work')
def Get_Work(All, Worker):
    result = ''
    for Work in All:
        if Work.User == Worker:
            result = str(Work.Domain) + ' / ' + str(Work.Work.SubDomain) + ' / ' + str(Work.Work) + ' ----- '
            return result
    return 'NA'
