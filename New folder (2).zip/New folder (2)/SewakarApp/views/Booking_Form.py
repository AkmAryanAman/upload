from django.shortcuts import render, redirect
from django.views import View
from SewakarApp.models.Service import ServiceDomain, ServiceSubDomain, ServiceWorker
from SewakarApp.models import SignUp


class BookingForm(View):
    def get(self, request):
        data = {}

        User = request.session.get('id')

        if User:
            data['user'] = SignUp.objects.get(id=User)
            data['Domain'] = ServiceDomain.get_all_services()

            Sector = request.GET.get('sector')

            if Sector:
                Domain = ServiceDomain.objects.get(id=Sector)
                data['sector'] = Domain
                data['SubDomain'] = ServiceSubDomain.get_all_SubDomain_By_Domain(Domain)
                try:
                    if 'Worker' in data.keys():
                        data.pop('Worker')
                finally:
                    pass

                Service = request.GET.get('service')
                if Service:
                    SubDomain = ServiceSubDomain.objects.get(id=Service)
                    data['service'] = SubDomain
                    data['Worker'] = ServiceWorker.get_all_Worker_By_SubDomain(SubDomain)
                    return render(request, 'booking_form.html', data)

                else:
                    return render(request, 'booking_form.html', data)

            else:
                return render(request, 'booking_form.html', data)

        else:
            return redirect('login')

    def post(self, request):
        Quantity = request.POST.get('Quantity')
        Duration = request.POST.get('Duration')
        Date = request.POST.get('Date')
        Sector = request.POST.get('Sector')
        Service = request.POST.get('Service')
        Worker = request.POST.get('Worker')

        cart = {'Quantity': Quantity,
                'Duration': Duration,
                'Date': Date,
                'Sector': Sector,
                'Service': Service,
                'Worker': Worker}

        request.session['cart'] = cart
        return redirect('Booking_Address')
