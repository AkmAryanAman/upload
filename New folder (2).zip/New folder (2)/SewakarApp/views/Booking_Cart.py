from django.shortcuts import render, redirect
from django.views import View
from SewakarApp.models.booking_model import BookingModel, PaymentDetails, Scheduling
from SewakarApp.models.signup import SignUp, Worker_Current_Status, Worker_Status_Name


class Booking(View):

    def get(self, request):
        User = request.session.get('id')
        if User:
            data = {'user': SignUp.objects.get(id=User)}
            data['booking'] = BookingModel.Get_Booking_By_User(data['user'])
            data['Payment'] = PaymentDetails.objects.filter(User=data['user'])

            return render(request, 'booking_cart.html', data)

        return redirect('login')

    def post(self, request):

        form = request.POST.get('Form')
        Point_Get = request.POST.get('Point')
        print(Point_Get)
        Booking_id = request.POST.get('Booking_id')

        if str(form) == 'Review_Worker':
            print(Booking_id)
            Booking_Detail = BookingModel.objects.get(id=Booking_id)

            Schedule_list = Scheduling.objects.filter(Booking=Booking_Detail)

            Status = Worker_Status_Name.objects.get(id=1)

            for Schedule in Schedule_list:
                worker = Worker_Current_Status.objects.get(User=Schedule.Worker)

                worker.Status = Status
                worker.Points = (int(worker.Points) + int(Point_Get)) / 2

                worker.save()

        return redirect('booking')


def RemoveBooking(request):
    booking_id = request.POST.get('remove_tag')
    BookingModel.objects.get(id=booking_id).delete()
    return redirect('booking')



