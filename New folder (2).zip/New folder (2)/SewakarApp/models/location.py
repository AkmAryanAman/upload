from django.db import models


# this Model is very Important , it defines the Location (State, District)
class State(models.Model):
    State = models.CharField(max_length=40, default='')

    def register(self):
        self.save()

    def __str__(self):
        return self.State


class District(models.Model):
    State = models.ForeignKey(State, on_delete=models.CASCADE, default='')
    District = models.CharField(max_length=40, default='')

    def register(self):
        self.save()

    def __str__(self):
        return self.District

    # Function returns the District By State
    @staticmethod
    def Get_District_By_State(State):
        try:
            result = False
            if District.objects.filter(State=State):
                result = District.objects.filter(State=State)
            else:
                result = False
        finally:
            return result
