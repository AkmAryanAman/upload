from django.db import models
from .signup import SignUp
from .Service import ServiceDomain, ServiceWorker


# This model have a collection of Work_Details of worker
# Here worker may have single work experience or multiple
# Means a single user may have multiple Domain or SubDomain
class WorkDetail(models.Model):
    User = models.ForeignKey(SignUp, on_delete=models.CASCADE, default='')
    Domain = models.ForeignKey(ServiceDomain, on_delete=models.CASCADE, default='')
    Work = models.ForeignKey(ServiceWorker, on_delete=models.CASCADE, default='')

    def register(self):
        self.save()

    # this static Function returns the Work_details using user
    @staticmethod
    def Get_Details_By_user(user):
        try:
            result = False
            result = WorkDetail.objects.filter(User=user)
        finally:
            return result

    # this static Function returns the Work_details using Domain
    @staticmethod
    def Get_Details_By_Domain(Domain):
        try:
            result = False
            result = WorkDetail.objects.get(Domain=Domain)
        finally:
            return result

    # this static Function returns the Work_details using SubDomain
    @staticmethod
    def Get_Details_By_work(Work):
        try:
            result = False
            result = WorkDetail.objects.get(Work=Work)
        finally:
            return result

    # this static function return About Worker using user and work
    @staticmethod
    def Get_Details_By_user_and_Work(user, work):
        try:
            result = False
            result = WorkDetail.objects.get(User=user, Work=work)
        finally:
            return result
