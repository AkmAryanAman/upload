from django.db import models
from .signup import SignUp


class Confirmation(models.Model):
    User = models.ForeignKey(SignUp, on_delete=models.CASCADE)
    Code = models.CharField(max_length=500, default='')

    def register(self):
        self.save()

    @staticmethod
    def Get_Code_By_User(user):
        try:
            result = False
            result = Confirmation.objects.get(User=user)
        except:
            pass
        return result
