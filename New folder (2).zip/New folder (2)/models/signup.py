from django.db import models
import datetime


# this Model Define the category of SignUp people
class Category(models.Model):
    Type = models.CharField(max_length=30, default='')

    def register(self):
        self.save()

    def __str__(self):
        return self.Type


# this model defines the All Members which is the part of our business
# In this , the primary information is collected
class SignUp(models.Model):
    First_name = models.CharField(max_length=30, default='')
    Last_name = models.CharField(max_length=30, default='')
    Mobile = models.CharField(max_length=13)
    Email = models.CharField(max_length=50, default='')
    Password = models.CharField(max_length=200, default='')
    Category = models.ForeignKey(Category, on_delete=models.CASCADE, default='')
    status = models.BooleanField(default=False)

    def register(self):
        self.save()

    def __str__(self):
        return self.Email

    # The function returns true, if email already exists
    def isExists(self):
        if SignUp.objects.filter(Email=self.Email):
            return True

        return False

    # this function return user information, if required email exist
    @staticmethod
    def get_people_by_email(email):
        try:
            return SignUp.objects.get(Email=email)
        except:
            return False


# this model accept another/Extra mobile no.
class Phone(models.Model):
    User = models.ForeignKey(SignUp, on_delete=models.CASCADE, default='')
    Mobile = models.IntegerField()

    def register(self):
        self.save()


# Define Status type for worker like Available, Suspend, Scheduled
# This Model work as source of Worker_Current_Status model
class Worker_Status_Name(models.Model):
    Status = models.CharField(max_length=50, default='')

    def __str__(self):
        return self.Status


# Define worker's current status
# After verification Worker Status is available
# During Suspending Worker Status is Suspend ..like this
class Worker_Current_Status(models.Model):
    User = models.ForeignKey(SignUp, on_delete=models.CASCADE)
    Status = models.ForeignKey(Worker_Status_Name, on_delete=models.CASCADE)
    Date = models.DateField(datetime.date.today())
    Points = models.IntegerField(default=5)

    def register(self):
        self.save()
