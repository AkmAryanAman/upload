from django.db import models
import datetime


class Feedback(models.Model):
    Name = models.CharField(max_length=50, default='')
    Email = models.CharField(max_length=50, default='')
    Feedback = models.CharField(max_length=500, default='')

    def register(self):
        self.save()


class Query(models.Model):
    Name = models.CharField(max_length=50, default='')
    Email = models.CharField(max_length=50, default='')
    Subject = models.CharField(max_length=100, default='')
    Query = models.CharField(max_length=500, default='')
    Type = models.IntegerField(default=0)

    def register(self):
        self.save()


class Comment_Query(models.Model):
    Query = models.ForeignKey(Query, on_delete=models.CASCADE)
    Comment = models.CharField(max_length=500, default='')
    Date = models.DateField(datetime.date.today())

    def register(self):
        self.save()
