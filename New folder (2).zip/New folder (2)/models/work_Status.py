from django.db import models


# this Model Define the Work_Status linked with booking model
class WorkStatus(models.Model):
    Type = models.CharField(max_length=100, default='')

    def register(self):
        self.save()

    def __str__(self):
        return self.Type