from django.shortcuts import render, redirect, HttpResponseRedirect
from django.contrib.auth.hashers import check_password
from SewakarApp.models import SignUp
from django.views import View


class Login(View):
    return_url = None

    def get(self, request):
        session_id = request.session.get('id')
        if session_id:
            return redirect('profile')
        else:
            if request.GET.get('return_url'):
                Login.return_url = request.GET.get('return_url')
            return render(request, "login.html")

    def post(self, request):
        email = request.POST.get('email').lower()
        password = request.POST.get('password')
        People = SignUp.get_people_by_email(email)

        error_massage = None
        if People:
            flag = check_password(password, People.Password)
            if flag:
                request.session['id'] = People.id
                request.session['first_name'] = People.First_name
                request.session['last_name'] = People.Last_name
                request.session['category'] = People.Category.id
                if People.Category.id == 3:
                    request.session['Admin'] = People.Category.id
                if Login.return_url:
                    return HttpResponseRedirect(Login.return_url)
                else:
                    Login.return_url = None
                    return redirect('main')
            else:
                error_massage = 'Entered Password is invalid !!'
        else:
            error_massage = 'Email or Password invalid !!'

        return render(request, "login.html", {'error': error_massage, 'email': email})


def logout(request):
    request.session.clear()
    return redirect('login')
