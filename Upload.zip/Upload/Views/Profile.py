from django.shortcuts import render, redirect
from SewakarApp.models import SignUp
from django.contrib.auth.hashers import check_password, make_password
from django.views import View
from SewakarApp.models.basic_details import BasicDetails


class Profile(View):
    def get(self, request):
        Id = request.session.get('id')
        print(Id)
        if Id:
            people = SignUp.objects.get(id=Id)
            data = {}
            data['Account_Info'] = people
            data['Success_msg'] = request.GET.get('msg')
            data['Error_msg_in_basic'] = request.GET.get('error_in_basic')
            data['Basic_Details'] = BasicDetails.get_Basic_Details_by_user(people)
            return render(request, 'Profile.html', data)

        else:
            return redirect('login')

    def post(self, request):
        Id = request.session.get('id')

        user = SignUp.objects.get(id=Id)

        form = request.POST.get('form')
        Work_Details = request.POST.get('work_Details')
        Basic_Details = request.POST.get('Basic_Details')
        print(BasicDetails)
        Contact_Info = request.POST.get('contact_Info')
        Address = request.POST.get('address')

        if form:
            self.Update_Password(user)

        elif Work_Details:
            self.Update_Work_Details(user)

        elif Basic_Details:
            msg = self.Update_Basic_Details(request, user)
            if msg:
                return redirect("profile?error_in_basic={msg}".format(msg=msg))
            else:
                return redirect('profile')

        elif Contact_Info:
            self.Update_Contact_Info(user)

        elif Address:
            self.Update_Address(user)

        else:
            return redirect('profile')

    def Update_Password(self, request, user):
        old = request.POST.get('old')
        new = request.POST.get('new')
        confirm = request.POST.get('confirm')

        if new == confirm:
            if check_password(old, user.Password):
                user.Password = make_password(new)
                user.save()
                return redirect('profile?msg=Password Update Successfully..')
            else:
                error_updatePassword = "You have entered wrong password"
                return render(request, "Profile.html", {'error_updatePassword': error_updatePassword})
        else:
            error_updatePassword = "Confirm Password is not Same as Password"
            return render(request, "Profile.html", {'error_updatePassword': error_updatePassword})

    def Update_Work_Details(self, request, user):
        pass

    def Update_Basic_Details(self, request, user):
        Get = BasicDetails.get_Basic_Details_by_user(user)
        if Get:
            error_msg = "You have already update your basic details...Please Contact to Manager"
            return error_msg
        else:
            father = request.POST.get('Father_name')
            mother = request.POST.get('Mother_name')
            dob = request.POST.get('DOB')
            gender = request.POST.get('Gender')
            blood = request.POST.get('Blood_Group')
            adhar = request.POST.get('Adhar')
            print("Good")

            Basic = BasicDetails(User=user,
                                 Father=father,
                                 Mother=mother,
                                 DOB=dob,
                                 Gender=gender,
                                 Blood_Group=blood,
                                 Aadhar=adhar)

            Basic.register()
            return False

    def Update_Contact_Info(self, request, user):
        pass

    def Update_Address(self, request, user):
        pass
