from django.contrib import admin
from SewakarApp.models.Category import Category
from SewakarApp.models.signup import SignUp, Phone
from SewakarApp.models import Status
from SewakarApp.models.Service import ServiceModel, Position
from SewakarApp.models.bookingmodel import BookingModel
from SewakarApp.models.location import District, State
from SewakarApp.models.Profession import WorkDetail
from SewakarApp.models.address import Address
from SewakarApp.models.basic_details import BasicDetails


class AdminBasicDetails(admin.ModelAdmin):
    list_display = ['User','Father', 'Mother', 'DOB', 'Gender', 'Blood_Group', 'Aadhar']


class AdminAddress(admin.ModelAdmin):
    list_display = ['User', 'Address_1', 'Address_2', 'Profession', 'Position', 'PinCode']


class AdminWorkDetail(admin.ModelAdmin):
    list_display = ['User', 'Profession', 'Position']


class AdminState(admin.ModelAdmin):
    list_display = ['Name']


class AdminDistrict(admin.ModelAdmin):
    list_display = ['state', 'Name']


class AdminPosition(admin.ModelAdmin):
    list_display = ['Profession','Name']


class AdminPhone(admin.ModelAdmin):
    list_display = ['Phone']


class AdminCategory(admin.ModelAdmin):
    list_display = ['Type']


class AdminStatus(admin.ModelAdmin):
    list_display = ['Type']


class AdminService(admin.ModelAdmin):
    list_display = ['Type']


class AdminSignUp(admin.ModelAdmin):
    list_display = ['First_name', 'Last_name', 'Email', 'Mobile', 'Category', 'Password', 'status']


class AdminBooking(admin.ModelAdmin):
    list_display = ['User', 'Quantity', 'Duration', 'Location', 'Date', 'Service', 'Status', 'Amount']


# Register your models here.
admin.site.register(Category, AdminCategory)
admin.site.register(Status, AdminStatus)
admin.site.register(ServiceModel, AdminService)
admin.site.register(SignUp, AdminSignUp)
admin.site.register(BookingModel, AdminBooking)
admin.site.register(Position, AdminPosition)
admin.site.register(Phone, AdminPhone)
admin.site.register(District, AdminDistrict)
admin.site.register(State, AdminState)
admin.site.register(WorkDetail, AdminWorkDetail)
admin.site.register(Address, AdminAddress)
admin.site.register(BasicDetails, AdminBasicDetails)
