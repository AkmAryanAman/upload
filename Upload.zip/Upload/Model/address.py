from django.db import models
from .signup import SignUp
from .location import State, District


class Address(models.Model):
    User = models.ForeignKey(SignUp, on_delete=models.CASCADE, default='')
    Address_1 = models.CharField(max_length=200, default='')
    Address_2 = models.CharField(max_length=200, default='')
    Profession = models.ForeignKey(State, on_delete=models.CASCADE, default='')
    Position = models.ForeignKey(District, on_delete=models.CASCADE, default='')
    PinCode = models.IntegerField()

    def register(self):
        self.save()

