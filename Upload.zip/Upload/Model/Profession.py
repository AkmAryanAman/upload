from django.db import models
from .signup import SignUp
from .Service import ServiceModel, Position



class WorkDetail(models.Model):
    User = models.ForeignKey(SignUp, on_delete=models.CASCADE, default='')
    Profession = models.ForeignKey(ServiceModel, on_delete=models.CASCADE, default='')
    Position = models.ForeignKey(Position, on_delete=models.CASCADE, default='')

    def register(self):
        self.save()

