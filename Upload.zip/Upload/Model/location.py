from django.db import models


class State(models.Model):
    Name = models.CharField(max_length=40, default='')

    def register(self):
        self.save()

    def __str__(self):
        return self.Name


class District(models.Model):
    state = models.ForeignKey(State, on_delete=models.CASCADE, default='')
    Name = models.CharField(max_length=40, default='')

    def register(self):
        self.save()

    def __str__(self):
        return self.Name
