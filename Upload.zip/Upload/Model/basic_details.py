from django.db import models
from .signup import SignUp



class BasicDetails(models.Model):
    User = models.ForeignKey(SignUp, on_delete=models.CASCADE, default='')
    Father = models.CharField(max_length=50, default='')
    Mother = models.CharField(max_length=50, default='')
    DOB = models.DateField()
    Gender = models.CharField(max_length=20, default='')
    Blood_Group = models.CharField(max_length=20, default='')
    Aadhar = models.IntegerField()

    def register(self):
        self.save()

    @staticmethod
    def get_Basic_Details_by_user(user):
        try:
            details = BasicDetails.objects.get(User=user)
            return details
        except:
            return False
