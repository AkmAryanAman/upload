from django.shortcuts import render, redirect
from SewakarApp.models import SignUp
from django.contrib.auth.hashers import check_password, make_password
from django.views import View


class Profile(View):
    def get(self, request):
        id = request.session.get('id')
        Success_msg = request.GET.get('msg')
        print(id)
        print(Success_msg)
        people = SignUp.objects.get(id=id)

        data = []
        Basic_detail = {'first_name': people.First_name,
                        'last_name': people.Last_name,
                        'email': people.Email,
                        'mobile': people.Mobile,
                        }

        data = {
            'Basic_detail': Basic_detail,
            'Success_msg': Success_msg
        }

        return render(request, 'Profile.html', data)

    def post(self, request):
        Id = request.session.get('id')

        form = request.POST.get('form')

        if form == 'password':
            old = request.POST.get('old')
            new = request.POST.get('new')
            confirm = request.POST.get('confirm')
            user = SignUp.objects.get(id=Id)

            print(old)
            print(new)

            if new == confirm:
                if check_password(old, user.Password):
                    user.Password = make_password(new)
                    user.save()
                    return redirect('profile?msg=Password Update Successfully..')
                else:
                    error_updatePassword = "You have entered wrong password"
                    return render(request, "Profile.html", {'error_updatePassword': error_updatePassword})
            else:
                error_updatePassword = "Confirm Password is not Same as Password"
                return render(request, "Profile.html", {'error_updatePassword': error_updatePassword})

        else:
            return redirect('profile')