from django.shortcuts import render, redirect
from SewakarApp.models import SignUp
from django.contrib.auth.hashers import check_password, make_password
from django.views import View
from SewakarApp.models.basic_details import BasicDetails
from SewakarApp.models.Service import ServiceModel, Position
from SewakarApp.models.Profession import WorkDetail


class Profile(View):
    data = {}
    data['Service'] = ServiceModel.get_all_services()

    def get(self, request):
        Id = request.session.get('id')
        print(Id)
        if Id:
            people = SignUp.objects.get(id=Id)
            self.data['Account_Info'] = people
            self.data['Success_msg'] = request.GET.get('msg')
            self.data['Error_msg_in_basic'] = request.GET.get('error_in_basic')
            self.data['Basic_Details'] = BasicDetails.get_Basic_Details_by_user(people)
            self.data['Work_Details'] = WorkDetail.Get_Details_By_user(people)
            try:
                if self.data['Position']:
                    self.data.pop('Position')
            except:
                pass

            return render(request, 'Profile.html', self.data)

        else:
            return redirect('login')

    def post(self, request):
        Id = request.session.get('id')

        user = SignUp.objects.get(id=Id)

        form = request.POST.get('form')
        Add_Profession = request.POST.get('profession')
        Add_Position = request.POST.get('position')
        Basic_Details = request.POST.get('Basic_Details')
        Contact_Info = request.POST.get('contact_Info')
        Address = request.POST.get('address')

        if form:
            self.Update_Password(user)

        elif Add_Profession:
            data = {}
            data = self.data
            data['Position'] = Position.objects.filter(Profession=Add_Profession)
            return render(request, 'Profile.html', data)

        elif Add_Position:

            position = Position.objects.get(id=Add_Position)
            profession = ServiceModel.objects.get(id=position.Profession.id)

            Add_work_Details = WorkDetail(User=user,
                                          Profession=profession,
                                          Position=position)

            Add_work_Details.register()
            return redirect('profile')

        elif Basic_Details:
            msg = self.Update_Basic_Details(request, user)
            if msg:
                return redirect("profile?error_in_basic={msg}".format(msg=msg))
            else:
                return redirect('profile')

        elif Contact_Info:
            self.Update_Contact_Info(user)

        elif Address:
            self.Update_Address(user)

        else:
            return redirect('profile')

    def Update_Password(self, request, user):
        old = request.POST.get('old')
        new = request.POST.get('new')
        confirm = request.POST.get('confirm')

        if new == confirm:
            if check_password(old, user.Password):
                user.Password = make_password(new)
                user.save()
                return redirect('profile?msg=Password Update Successfully..')
            else:
                error_updatePassword = "You have entered wrong password"
                return render(request, "Profile.html", {'error_updatePassword': error_updatePassword})
        else:
            error_updatePassword = "Confirm Password is not Same as Password"
            return render(request, "Profile.html", {'error_updatePassword': error_updatePassword})

    def Update_Profession(self, Service):
        pass

    def Update_Basic_Details(self, request, user):
        Get = BasicDetails.get_Basic_Details_by_user(user)
        if Get:
            error_msg = "You have already update your basic details...Please Contact to Manager"
            return error_msg
        else:
            father = request.POST.get('Father_name')
            mother = request.POST.get('Mother_name')
            dob = request.POST.get('DOB')
            gender = request.POST.get('Gender')
            blood = request.POST.get('Blood_Group')
            adhar = request.POST.get('Adhar')
            print("Good")

            Basic = BasicDetails(User=user,
                                 Father=father,
                                 Mother=mother,
                                 DOB=dob,
                                 Gender=gender,
                                 Blood_Group=blood,
                                 Aadhar=adhar)

            Basic.register()
            return False

    def Update_Contact_Info(self, request, user):
        pass

    def Update_Address(self, request, user):
        pass
